let escalaCores = [
    {
        cor: 'red',
        rgb: '#FF0000'
    },
    {
        cor: 'green',
        rgb: '00FF00'
    },
    {
        cor: 'white',
        rgb: 'FFFFFF'
    }
    ];

console.log(escalaCores.map(cores =>[cores.cor,cores.rgb]))


let student = {
        nomeProf: 'Alana Morais',
        disciplina: 'LS',
        matricula: 35453
    };

console.log(`A quantidade de propriedades do objeto é: ${Object.keys(student).length}`)